package MYGUI;

import java.util.Vector;

import javax.swing.JList;
import javax.swing.ListModel;

import View.ConfigColor;



public class MetroList extends JList {

	public MetroList() {
		super();
		this.setBackground(ConfigColor._bgEDP);
	}


	
	
}
