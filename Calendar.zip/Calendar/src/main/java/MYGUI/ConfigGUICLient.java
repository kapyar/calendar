package MYGUI;

import java.awt.Color;

public class ConfigGUICLient {
	
	/** FontType uses in Titles */
	public static String FontType = "Segoe UI";
	
	
	/** _yCcoordinateTitleLabels */
	public static int  _yTL = 62;
	/**_WeightTitleLabels*/
	public static int  _WTL = 500;
	/**_HeigtTitleLabels*/
	public static int  _HTL = 36;
	
	
	/** button Nubmer Size */
	public static int bNS =42;
	/** Enter button weight */
	public static int btnEW = 80;
	
	/** Foreground My Bnt*/
	public static Color _bFG = new Color (255,255,255);
	
	/** Backgrund MyBnt*/
	public static Color _bBG = new Color (0,119,0);

	/**setHoverBackgroundColor MyButton */
	public static Color _bHBC = new Color (100,100,100);

	/**setPreseedBackgroundColor MyButton*/
	public static Color _bPBC = new Color (34,34,34);;
	
	;
	

	
	
	
}
