package Model;

public class Config {

	public String CURRET_LOGIN = null;
}
