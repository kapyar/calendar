package Strategy;

import java.io.Serializable;

import Model.EventHolder;

public class EmptyStrategy extends Strategy {

	@Override
	public void send(EventHolder e) {
		// TODO Auto-generated method stub

	}

}
