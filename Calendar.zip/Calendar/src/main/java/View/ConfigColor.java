package View;

import java.awt.Color;

public class ConfigColor {
	 
	/** Color Login Panal BackGround*/
	public static Color _logBG = new Color (58,58,58);
	
	/** Color radion btn on LOgin*/
	public static Color _rbtnBG = new Color (58,58,58);

	/** Color clear filds in login*/
	public static Color _clFlBG= new Color (58,58,58);

	/**Magic main color */
	public static Color _MAINcolor =new Color (34,34,34);
	
	/** Color filds in calendar work day*/
	public static Color _cwkBG= new Color (58,58,58);

	/** Color filds in calendar weekend (non work day)*/
	public static Color _cnwkBG = new Color (0,119,0);
	
	/** Color filds in calendar today*/
	public static Color _ctBG =new Color (80, 2,27).brighter();

	/** Cool color for girl in choser panel*/
	public static Color _bCTC  =new Color (96,177,184);

	/** Cool color for girl in choser panel
	 * setHoverBackgroundColor MyButton */
	public static Color _bCHBC = new Color (96,177,184);
	

	/** Cool color for girl in choser panel
	 * setPreseedBackgroundColor MyButton */
	public static Color _bCPBC  = new Color (14,29,32);

	/**Edidable panel color */
	public static Color _bgEDP =   new Color (235,235,235);
	}
